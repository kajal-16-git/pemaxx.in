<?php
include_once('header.php');
?>
        <link rel="preconnect" href="https://www.google-analytics.com" crossorigin/>
        <link rel="preconnect" href="https://www.googletagmanager.com" crossorigin/>
        <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin/>
        <link rel="preconnect" href="https://api-iam.eu.intercom.io" crossorigin/>
       
        <title>Forex Account Security – pemaxx</title>
        <meta name="description" content="3D secure Visa/Mastercard authorization with an SSL-protected personal area and more advanced measures from pemaxx to ensure your funds are secure 24/7."/>
        <meta name="keywords" content="deposit, withdrawal, withdraw, instant, liberty, reserve, libertyreserve, lr, moneybokers, skrill, webmoney, bank, wire, forex, forex trading, broker, currency trading, deposit, bonus, forex broker, no requote, no deposit bonus, deposit bonus, visa, mastercard"/>
       
        <meta property="fb:admins" content="315931161787264"/>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta name="google-site-verification" content="C_FIt4lBjGhpRtmbxPouNCe1tl6MGUiy3kONxjoQZzg"/>
      
        <meta name="msapplication-TileImage" content="/mstile-150x150.png"/>
        <meta name="msapplication-TileColor" content="#0A2C63"/>
        <meta name="amplitude-api-key" content="103d0a7b114c86c88bcffd5a52d7cbec"/>
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
        <link rel="manifest" href="/site.webmanifest">
        <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
        <meta name="msapplication-TileColor" content="#2b5797">
        <meta name="theme-color" content="#ffffff">
        <link rel="stylesheet" type="text/css" href="https://octacdn.net/assets/css/layout.css?e0d3fcec5178164dd742a6b8a93e7eb6a558e241"/>
        <link rel="stylesheet" type="text/css" href="https://octacdn.net/assets/css/page-security.css?ae1de284765ae1445e44d2322ade498e75f4fe05"/>
       
    </head>
    <body class="">
       
        <style>

            @media screen and (max-width: 760px) {
                ._redesign .QqhHr {
                    min-width:0
                }
            }


           
            @media screen and (max-width: 1000px) {
                ._redesign .kkHkd {
                    display:inline-flex
                }
            }

            /**/

            /**/
            @media screen and (max-width: 1000px) {
                .TqurE {
                    align-items:center;
                    display: flex;
                    height: 60px;
                    left: 0;
                    padding: 0 8px;
                    position: absolute;
                    top: 0;
                    transition: background-color .4s;
                    width: 100%;
                    z-index: 501
                }

                 .content-container__title-group {
        margin-left: 0; /* Remove large margin for mobile view */
        text-align: center;
    }

    .title-t01 {
        color: #e1d9d9;
        text-align: center;
    }

    /* For larger screens */
    @media (min-width: 1024px) {
        .content-container__title-group {
            margin-left: -788px; /* Restore large margin for desktop view */
        }
    }

        </style>
       
       
        <main class="main-container">
            <section class="content-container">
               <!--  <div class=""><img src="assets/images/bg/bg_3.jpg" style=" background-size: cover; background-position: bottom; height: 30ch;width: 1526px;"></div>
                <div class="content-container__inner" style="margin-top :-188px;">
                    <div class="pg-wrap">
                        <div class="content-container__title-group">
                            <h1  class="title-t01" style="color: black;">Funds security
                    </h1>
                        </div>
                    </div> -->
                  <section class="breadcrumb mb-0" style="background-image: url(assets/images/bg/bg_3.jpg); background-size: cover; background-position: bottom; height: 30ch;">
    <div class="container pt-5">
        <div class="pt-5"></div>
        <h1 class="fs-2 text-white pt-5 mt-3">Funds security</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php" class="text-light">Home</a></li>
                <li class="breadcrumb-item active text-light" aria-current="page">Funds security</li>
            </ol>
        </nav>
    </div>
</section>

                    <div class="security-intro">
                        <div class="pg-wrap">
                            <div class="security-intro__inner">
                                <div class="security-intro__title">Our traders' funds security is our top priority
                        </div>
                                <p class="security-intro__content">With us, you can be sure your deposits are protected in every way. Here are some of the measures we take to ensure your funds are protected:
                        </p>
                            </div>
                        </div>
                    </div>
                    <div class="pg-wrap">
                        <ul class="security-features">
                           <!-- <li class="security-features__item -option-accounts">
                                <div class="security-features__item-inner">
                                    <div class="security-features__item-content">
                                        <h3 class="security-features__item-title">Segregated accounts</h3>
                                        <p class="security-features__item-caption">In accordance with international regulation standards, we use separate accounts to keep our traders' funds segregated from the company's balance sheets. This keeps your funds secure and untouched.</p>
                                    </div>
                                </div>
                            </li>-->
                            <li class="security-features__item -option-ssl">
                                <div class="security-features__item-inner">
                                    <div class="security-features__item-content">
                                        <h3 class="security-features__item-title">SSL-protected personal area</h3>
                                        <p class="security-features__item-caption">We use highly secure technology to protect your personal data and financial transactions. SSL-secured profile will keep your data safe and inaccessible to any third parties thanks to strong encryption.</p>
                                    </div>
                                </div>
                            </li>
                            <li class="security-features__item -option-verification">
                                <div class="security-features__item-inner">
                                    <div class="security-features__item-content">
                                        <h3 class="security-features__item-title">Account verification</h3>
                                        <p class="security-features__item-caption">We recommend you verify your account by submitting a scan of your personal ID and address proof. This measure will make sure your transactions are authorised and secure.</p>
                                    </div>
                                </div>
                            </li>
                            <li class="security-features__item -option-withdraw">
                                <div class="security-features__item-inner">
                                    <div class="security-features__item-content">
                                        <h3 class="security-features__item-title">Secure withdrawal rules</h3>
                                        <p class="security-features__item-caption">Since withdrawal from a real account becomes available only after email confirmation, only you can access your funds. It is also required that you use the same payment details for deposits and withdrawals. Thus, under no circumstances can we transfer your withdrawal to an unauthorised third party.</p>
                                    </div>
                                </div>
                            </li>
                            <li class="security-features__item -option-3ds">
                                <div class="security-features__item-inner">
                                    <div class="security-features__item-content">
                                        <h3 class="security-features__item-title">3D Secure Visa authentication</h3>
                                        <p class="security-features__item-caption">We apply the 3D Secure technology when processing credit and debit cards. This technology makes all Visa transactions transparent and safe.</p>
                                    </div>
                                </div>
                            </li>
                            <li class="security-features__item -option-support">
                                <div class="security-features__item-inner">
                                    <div class="security-features__item-content">
                                        <h3 class="security-features__item-title">Advanced protection</h3>
                                        <p class="security-features__item-caption">Our technical environment is monitored 24/7 by a dedicated team of professional security engineers and technical specialists. They have developed and maintain top level protection, so any data loss, damage, or other technical issues are highly unlikely.</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                        <!--<div class="security-btn-wrap -centred">
                            <a class="btn-t02 -arr-r -text-s02 security-btn" href="https://crm.pemaxx.com/register" data-auto-event-category="cta_click" data-auto-event-action="deposit-my-account" data-auto-event-label="deposit-my-account-security" style="background-color:#ff561c;">
                                <span class="btn-t02__inner">Deposit funds</span>
                            </a>
                        </div>-->
                         <div class="security-btn-wrap -centred">
                            <a href="https://crm.pemaxx.com/register" class="btn btn-warning mt-3 hover" style="background-color:#ff561c;height: 37px;">Deposit funds</a>
                        </div> 
                    </div>
                </div>
            </section>
        </main>
       
       
            <?php   include_once('footer.php'); ?>