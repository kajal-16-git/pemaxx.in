<?php
include_once('header.php');
?>

<style>
    body{
        background-color:#8080801f ;
    }
</style>

 <section class="breadcrumb mb-0" style="background-image: url(assets/images/bg/bg_1.jpg); background-size: cover; background-position: bottom; height: 30ch;" >
        <div class="container pt-5">
          <div class="pt-5"></div>
          <h1 class="fs-2 text-white pt-5 mt-3">stochastic-based strategy</h1>
          <nav class="breadcrumb text-light">
            <a class="breadcrumb-item text-light" href="index.php">Home</a>
            <a class="breadcrumb-item text-light" href="trading_strategies.php">Trading Strategies</a>
            <span class="breadcrumb-item active text-light" aria-current="page">stochastic-based strategy</span>
          </nav>
        </div>
      </section>


      
        <section>
    <div class="container my-5">
        <div class="card p-4">
            <div class="card-body">

                <!-- Main Heading Section -->
                <div class="row">
                    <div class="col-12">

                        <h4 style="margin-left:-17px;display: flex;font-size: xxx-large; justify-content: center">A simple stochastic-based<br> strategy to trade in a flat market</h4>
                    </div>
                </div>

                <!-- Text Section (First Paragraph) -->
                <div class="row my-4">
                    <div class="col-12">
                        <p style= "display: flex; justify-content: center">
                           This strategy will teach you to trade in a flat market using one of the most common indicators.</p>

                        

                    </div>
                </div>
               </div> 
                        <div class="col-12 col-md-8 mx-auto mb-4" style="padding-left: 62px;">
                            <p><b>Timeframe:</b> H4 chart for candlestick analysis, M15 chart for trading</p>
                     <p><b>Currency pairs:</b> all</p>
                      <p><b>Market state:</b>flat</p><br>
                            <p><b>Required indicators:</b></p>
      <ul  style="list-style-type:disc; ">
        <li>Stochastic (14, 3, 3)</li>
        <li>An inside bar of a H4 chart (price action pattern: a candle which closed inside the range of previous candlesticks)</li>
      </ul><br>
       
       <p><b>Entry steps for a short position<span style="color:red;"> (Sell):</span></b></p>
      <ul  style="list-style-type:number; ">
        <li>ook for an inside bar on H4 timeframe and mark its borders.</li>
        <li>Jump to the M15 timeframe and wait for the price to touch the lower border.</li>
        <li> Make sure that the stochastic's value is less than 20.</li>
        <li> Look for the first bullish candlestick closing above the lower border.</li>
      </ul><br><br>

        <p><b>Stop Loss:</b> Place a Stop Loss below the previous swing low.<br></p>
      
                     <p><b>Take Profit:</b><br> Take your Take your profit when the risk to reward ratio reaches 1:2 or when the price touches the opposite borderline.</p>
                     

  </div>

             <div class="mb-5" style="display: flex; justify-content: center;">
                            <img src="assets/images/logo/trading-strategt.png" alt="Alert Icon" style="width: 70%; height: auto; border-radius: 26px;">
                            </div>

                            <div style="display: flex; justify-content: center;">
                            <img src="assets/images/logo/trading-strategt-3.png" alt="Alert Icon" style="width: 70%; height: auto; border-radius: 26px;">
                            </div>

   <div class="container my-4">
    <center>
       
    </center>
</div>

   <div class="col-12 col-md-8 mx-auto mb-4" style="padding-left: 62px;">

      <ul  style="list-style-type:number; ">
        <p><b>Entry steps for a long position<span style="color:green;"> (Buy):</span></b></p>
        <li>Look for an inside bar on H4 timeframe and mark its borders.</li>
        <li>Jump to the M15 timeframe and wait for the price to touch the lower border.</li>
        <li> Make sure that the stochastic's value is less than 20.</li>
        <li>Look for the first bullish candlestick closing above the lower border.</li>
      </ul><br>
      <div>
      <b>Stop Loss</b>
      <p>Place a Stop Loss below the previous swing low.</p><br>

      <b>Take Profit</b>
      <p>Take your profit when the risk to reward ratio reaches 1:2 or when the price touches the opposite borderline.

      </p>
      <div>
          <img src="assets/images/logo/trading-strategt2.png" class="img-fluid" alt="Trading image 1">
      </div><br><br>

      <div>
          <img src="assets/images/logo/trading-strategt-4.png" class="img-fluid" alt="Trading image 1">
      </div><br><br>
       
      <div style="text-align: center;">
    <a href="https://crm.pemaxx.com/register" class="btn btn-warning mt-3 hover" style="background-color:#ff561c; border-radius:15px;">Trade Now</a>
    </div>


    </div><br><br>
    
                   
      <div class="container my-4">
    <center>
        <div class="p-4 bg-light" style="border-radius:56px;">
            <h5>Download indicators settings to your desktop platform</h5>
            <p>If you're looking for a quick method to apply the indicators from this strategy, click on the button below. Read detailed instructions <a href="#">here</a>.</p>
            
            <div class="row justify-content-center">
                <div class="col-12 col-md-4 my-2">
                    <a href="#" class="btn w-100" style="background-color: #fff; border-radius:25px;">Settings for MT5</a>
                </div>
            </div>
        </div>
    </center>
</div>


             
</section>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<?php
include_once('footer.php');
?>