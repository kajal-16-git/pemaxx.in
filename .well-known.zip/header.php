
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">

   <head>
    <title>Pemaxx Liquidity</title>
    <meta charset="UTF-8">
    <meta name="description" content="MT5 White label, MT5 White label cost,Trading,Gold,Gold Trading,nasdaq,SPX500,Dow jone, Forex liquidity solutions, Forex, Cryptocurrency,india,dubai, CFD liquidity provider and White label solutions. Turnkey solutions for Forex and Crypto brokers,Trade with reliable broker and best conditions: low spreads, no swaps, no commissions. Claim and withdraw 50% deposit bonus!">
    <!-- <meta name="keywords" content="MT5 White label, MT5 White label cost,Trading,Gold,Gold Trading,nasdaq,SPX500,Dow jone, Forex liquidity solutions, Forex, Crypto, Stock CFD White label,india, dubai,best froex broker,forex, forex trading, broker, currency trading, deposit, bonus, forex broker, no requote, no deposit bonus, deposit bonus, visa, mastercard"> -->
   
     <meta name="keywords" content="forex,forex factory,forex trade,forex capital markets,forex rates,gcm forex,insta forex,forex bank,forex club,forex rate,forex live,forex news,mustafa forex,easy forex,robo forex,trade forex,forex factory calendar,forex exchange,forex valuta,khaleej times forex,uk forex,forex calendar,forex signals,xm forex,forex market,forex world,forex pros,sydney forex,seputar forex,maybank forex,forex com,forex online,forex forum,forex signal,forex se,forex chart,bdo forex,forex pro,forex pk,what is forex,forex paradise,forex chile,hdfc forex card,forex broker,forex video,forex trading strategies,forex empire,oanda forex,free forex signals,forex rate in pak,forex calculator,global forex institute,forex brokers,forex trader,integral forex,forex converter,forex peace army,city forex,aussie forex,action forex,forex market hours,forex no deposit bonus,no deposit bonus forex,forex info,us forex,live forex rates,forex rate pakistan,belajar forex,que es forex,forex exchange rate,forex valutakurser,forex valutaomvandlare,gold forex,hdfc forex card login,broker forex,forex directory,forex ru,canada forex,forex tester,canadian forex,best forex broker,forex broker inc,forex demo,forex exchanges,hdfc forex rates,fbs forex,forex malaysia,public bank forex,dbs forex,forex com pk,forex wiki,forex vps,forex strategies,cheap forex vps,forex swap,yahoo forex,forex winner,forex robots,forex indicators,daily forex,forex winners,forex times,hot forex,forex card,thomas cook forex,forex crunch,oz forex,best forex vps,forex news today,forex indonesia,xe forex,forex cargo,forex trade platforms,best forex trading platforms,forex trading for beginners,forex options,forex rates live,alfa forex,bpi forex,forex forward,pips forex,forex meaning,uk forex review,forex trading tutorial,netdania forex,forex economic calendar,forex investors,live forex,forex trading tips,nz forex,forex streaming,forex game,forex mobile,forex factory news,live forex signals,forex trend,e forex,n z forex,forex live rates,apa itu forex,forex demo account,forex stockholm,analisa forex,berita forex,fnb forex,1st contact forex,forex models,khaleej forex,forex trading hours,cimb forex,forex investments,forex define,live forex chart,forex trading signals,forex calender,forex trading training,forex forecast,forex strategy,forex time,scalping forex,forex trading in india,signal forex,forex shop,forex trading software,forex traders,robot forex,weizmann forex,factory forex,buy forex,ea forex,forex rates today,standard bank forex,forex trading system,online forex trade,khaleej times gold forex,best forex brokers,forex trading course,top forex brokers,learning forex,forex bonus,forex training,vps hosting for forex,forex trading application,forex street,forex eur usd,forex analysis,forex quote,trader forex,forex review,investing forex,forex tips,i forex,fx forex,india forex reserves,forex graph,www forex com,forex blogs,best forex signal,forex pakistan,forex philippines,forex signals free,forex wikipedia,forex currencies,forex factory com,forex money,forum forex,forex mexico,forex scams,forex ea,maybank forex rate,raffles forex,online forex trading,demo forex,cara bermain forex,axis bank forex card,sbi forex rates,www forex se,fnb forex rates,valutaomvandlare forex,learn forex trading,forex trading review,forex magnates,forex vps hosting,forex broker reviews,forex trading strategy,forex hours,forex strategies resources,forex reserves,forex forums,forex app,forex nz,forex solutions,forex canada,forex spot,rsi forex,fibonacci forex,forex technical analysis,forex scalping,hukum forex,finanzas forex,economic calendar forex,money forex,forex handel,forex pdf,hdfc forex,vps forex,buy forex online,forex usd rub,learning to trade forex,metatrader 4 forex,forex currency strength meter,forex currency rates,forex 500,lite forex,weizmann forex ltd,www forex com pk,analisa forex hari ini,forex no,bsp forex,forex markets,forex mt4,forex profit calculator,www khaleejtimes com forex asp,vps forex hosting,axis bank forex card login,forex material,forex live charts,forex pips,forex definition,forex trading for dummies,managed forex account,forex gbp eur,forex today,easy forex login,forex tutorial,forex signal providers,nfp forex,investopedia forex,forex strategie,ig forex,forex news calendar,broker forex terbaik,pak forex,best forex strategy,forex for dummies,forex gold,www netdania com forex rates,forex colombia,amex forex,no deposit forex bonus,best forex indicator,pakistan forex rate,vkc forex,forex world tracking,forex fi,forex book,forex scalping strategy,indicator forex,forex uk,forex accounts,forex trading online,swiss forex,forex spreads,forex tracking,axis bank forex rates,hdfc bank forex rates,icici forex card,forex currency converter,icici forex rates,forex bureau,forex euro,forex oslo,forex revolution,forex trading forums,free forex charting,forex trading strategies pdf,forex companies,forex time zone,forex p l,invest in forex,forex trader salary,top 10 forex brokers,forex course,citi forex,best forex,online forex,forex mentoring,forex pl,forex system,urban forex,talking forex,forex brokers list,forex live chart,money management forex,citibank forex,eurusd forex,forex risk,pk forex,earn forex,forex signals service,forex predictions,forex millionaires,forex us dollar to philippine peso,xtb forex,forex volatility,forex usd,forex youtube,pakistan forex forum,forex currency exchange,hedging forex,macd forex,forex alert,forex australia,best forex robot,silver forex,www forex,alpari forex,forex online trading,forex trading demo,united states forex brokers,forex platform,forex leverage,hdfc forex login,windows forex vps,nedbank forex,icici bank forex rates,forex india,forex trendy,sbi forex card,forex open,best forex trading,forex trading simulator,eur usd forex,forex binary option,forex education,forex correlation,forex dealer,forex board,forex basics,forex com review,forex api,www easy forex com,waluty online forex,reuters forex,forex no deposit bonus without verification,forex clock,ema forex,real time forex,forex trader jobs,forex price action,forex news live,forex login,best forex book,forex candlestick patterns,forex yahoo,czarina forex,forex rsi,forex history,forex trading books,forex contest,forex signals live,pak forex rates,hsbc forex,forex free signals,exness forex,uk forex login,successful forex traders,tradeking forex,trade forex online,forex software,forex trading demo account,forex future,100 forex brokers,oanda forex rates,forex widget,best forex ea,hdfc bank forex card,forex tester 2,forex tv channel,first contact forex,american express forex,pepperstone forex,rbi forex rates,forex cargo tracking,forex 50,supply and demand forex,forex rates india,forex currency rate,forex flex ea,ecb forex rates,forex rates in uganda,no deposit bonus forex 2015,forex investopedia,spread forex,forex vs stocks,learn how to trade forex,copy trading forex,streaming forex rates,think forex,astro forex,forex transaction,forex tester 2 crack,assiom forex,forex binary options,forex trading pdf,martingale forex,forex market news,forex master,forex pip calculator,forex charts live,forex com uk,forex eur gbp,forex for a living,forex success stories,forex money management,forex usd eur,forex trading education,forex websites,forex historical data,daily forex signals,forex tools,forex fx,best forex signal provider,leverage forex,us forex reviews,forex brokers australia,uob forex,forex patterns,forex business,forex data,easy forex com,forex live news,forex bitcoin,us forex review,forex maybank,cms forex,forex balikbayan box,forex magazine,ava forex,euro forex,forex day trading,forex cfd,free forex signals live,india forex,forex rebates,forex fundamental analysis,expert advisor forex,crude oil forex,forex trading games,forex conversion,forex nepal,forex programming,no deposit bonus forex 200,no deposit forex,best time to trade forex,us forex brokers,forex hedging,naked forex pdf,hdfc forex card rates,forex exchange rates live,Pemaxx forex,wall street forex robot,forex jobs,forex card hdfc,citibank forex rates,forex dollar,vps forex terbaik,post office forex,forex opening hours,traders forex,gft forex,forex logo,forex trading news,forex lot,forex wallpaper,forex factory forum,forex trading strategies that work,forex managed account,ecn forex,forex chart patterns,forex learn,forex money transfer,forex hedging strategy,sbi forex,best forex trading strategy,usd forex,forex daily,forex news feed,forex strategy builder,forex university,forex trading robot,forex trading uk,daily forex news,how forex works,forex market opening times,forex israel,forex strategies revealed,forex margin,forex trading jobs,swap forex,forex print,forex new,forex robot reviews,live forex news,forex risk management,forex cargo uk,best free forex signals,forex profit,forex academy,forex position size calculator,forex trend indicator,usd rub forex,forex margin calculator,master forex,daily forex calendar,forex metal,forex pk open market rates,fractals forex,forex usa,forex money exchange,forex option trading,forex platforms,cfd forex,swing trading forex,forex trading wiki,automated forex trading,interactive brokers forex,best forex platforms,forex trading company,trading forex for a living,ib forex,top forex traders,forex trading chart,forex affiliate,shift forex,western union forex,forex crude oil,cashback forex,current forex rates,forex reserves india,forex army,forex trading times,forex metatrader,best forex broker in the world,best broker forex,top forex broker,best forex bonus,define forex,forex broker comparison,the forex guy,forex compounding calculator,forex trading strategies for beginners,interbank forex,free forex trading signals,forex trading for beginners pdf,realtime forex,global forex trading,forex turkiye,forex market analysis,forex trading guide,forex gbp usd,forex news trading,forex calander,hdfc netbanking forex,forex school online,best forex trading system,forex training course,make money with forex,forex box tracker,forex fibonacci,money pl forex,live forex quotes,forex trading scams,forex competition,forex real time,real time forex charts,forex shipping,forex brokers uk,divergence forex,forex ebook,forex lot size calculator,forex waluty online,etoro forex,forex pivot points,uk forex brokers,google forex,forex for beginners pdf,free forex,market forex,easy forex review,aud forex,forex guide,forex charts online,cci forex,forex trading india,forex bot,forex services,forex t v,historical forex rates,forex factory app,forex live signals,forex strength meter,forex reddit,forex dashboard,forex tv,2nd skies forex,xm forex review,forex mustafa,forex forex,average true range forex,free forex robot,forex currency trade,forex trading account,nepal forex,low spread forex broker,forex practice accounts,compare forex brokers,forex lot size,day trading forex,forex trading brokers,cable forex,trusted forex brokers,forex currency exchange rates,forex signal indicator,candlestick forex,forex ea generator,forex rates philippines,icici forex,forex trendy review,forex reserve,forex xe,forex rates uganda,global prime forex,free forex trading,netdania forex charts,nepal rastra bank forex,forex oil,basics of forex trading,leverage in forex,arbitrage forex,fundamental analysis forex,forex chart online,forex volume,forex ecn,forex seminar,tradeview forex,forex london,pakistan forex reserves,forex usd gbp,forex sessions,forex session times,forex chat,forex tester 2 crack full,forex day trading strategy,forex supply and demand,forex stocks,forex trade copier,forex torrent,bpi forex rates,forex articles,forex webinars,forex traders in kenya,forex ema,forex dinar,x forex,forex binary,forex pak,forex index,forex news gun,hdfc bank forex card login,forex mentor pro,forex prekyba,candlestick patterns forex,is forex legit,forex deposit bonus,forex exchange market,binary forex,forex managed accounts,uk forex rates,saxo bank forex,forex 101,axis forex card login,live charts forex,accurate forex signals,forex sentiment,forex signals reviews,best forex rates,forex gold price,forex compare,mti forex,slippage forex,wiki forex,richest forex traders,live forex trading,free forex indicators,forex ltd,forex gold rate,forex broker inc review,bloomberg forex news,forex guru,best forex indicators free download,best indicators for forex,forex price action scalping pdf,gps forex robot,best forex trading platform for beginners,forex trading coach,tnt forex,forex hedge,forex italia,etrade forex,forex swing trading,forex trader pro,forex trading courses,forex trading blogspot,forex brokers usa,barclays forex,forex affiliate programs,demo account forex,trading strategies forex,forex secrets,axis bank forex,forex videos,axis forex card,simple forex strategy,forex factory economic calendar,forex megadroid,bangkok bank forex,forex banks,forex card sbi,icici bank forex card,forex rate in india,forex factory calender,hsbc forex rates,forex iqd,forex dollar to philippine peso,simple forex tester,currency converter forex,forex tester 2 keygen,forex report,ecn forex broker,oil forex,oanda forex trading,capital one forex,forex capital markets ltd,the best forex broker,forex market times,list of forex brokers,forex candlestick,trading forex for beginners,historical forex data,forex explained,forex live quotes,forex trade signals,forex systems,forex market hours clock,forex wave,forex trading sessions,forex trading plan,forex hedge funds,forex market time,td ameritrade forex,forex leverage calculator,pips in forex,forex trading course for beginners,forex tax,metatrader forex,acm forex,forex site,forex free bonus,forex pakistan open market,pivot points forex,best forex broker 2015,most volatile forex pairs,best forex trader,forex box,trading system forex,iqd forex,philippine forex,gold prices forex,forex spread betting,forex download,spot forex,futures forex,forex funds,forex stock,forex paypal,professional forex trader,forex f,forex scanner,fxcm forex,historical forex,the forex,gbp usd forex,forex calendar news,forex trading ideas,atr forex,forex sweden,best forex robots,pamm forex,buy forex signals,forex capital markets careers,forex price action scalping,best forex trading books,carry trade forex,usd eur forex,uk forex exchange rates,forex support and resistance,pivot point forex,the forex trading coach,forex rates pakistan open market live,about forex,forex copier,youtube forex,forex traders in india,forex indicators download,forex usd jpy,latest forex news,forex watch,forex risk calculator,forex internship,forex live currency rates,forex oil prices,forex ea reviews,forex com au,bk forex,forex settlement,hedging in forex,binary options forex,action forex pivot points,understanding forex trading,best forex broker in usa,best forex trading software,forex social trading,forex images,forex market open,forex trading time,forex copy trading,regulated forex brokers,binary options vs forex,forex millionaire,trading in forex,automatic forex trading,forex spot rates,forex exchange rates calculator,ebook forex,best ea forex,reuters forex rates,lot size forex,dollar forex,forex technicals,forex travel card,bollinger bands forex,forex rates oanda,free forex ea,easy forex classic,uganda forex rates,bank of ghana forex rates,forex expo,forex trading journal,icici bank forex card login,bank of uganda forex rates,donna forex,pak forex open market,forex capital markets llc,automated forex trading system,forex automated trading,r forex,about forex trading,learning forex trading,forex trade signal,forex trading group,forex journal,forex brokers review,free forex training,forex trading success stories,forex capital,forex prices,forex trends,forex graphs,forex trading analysis,forex united states,islamic forex,forex fees,forex trading indicators,simple forex trading strategies,forex trading for dummies pdf,forex ee,forex on line,usd cad forex,hdfc forex plus card login,forex scalping system,forex online charts,investopedia forex simulator,forex instagram,forex swing trading strategy,forex oanda,forex mlm,ocean sky forex,forex terminology,simple forex trading strategy,cot report forex,elliott wave forex,forex trading lessons,forex classic,forex trading scam,forex growth bot,forex class,forex trading videos,1 lot forex,understanding forex,freedom forex,forex capital market,forex no deposit bonus new,binary options forex signals,forex guy,forex screener,forex candlestick patterns pdf,forex cad usd,forex trgovanje,forex fxcm,canadian forex reviews,forex rates live pakistan,forex analyst,forex android,forex rub usd,forex free,managed forex,retail forex,forex price action strategy,uk forex currency converter,forex hacked,stop loss forex,forex diamond,forex position,forex cashback,stocks vs forex,practice forex trading,forex trade online,forex trading broker,forex trading tools,forex bureau near me,forex charting software,forex trading website,forex station,demo forex trading,forex demo accounts,forex trading market,major forex pairs,nrb forex,easy forex trading,learn forex trading online,harmonic patterns forex,forex action,forex trading calculator,learn forex trading for beginners,automated forex trading software,forex auto trading,forex trading mentorship,auto trading forex,tradestation forex">
   
        <!-- Open Graph Data -->
    <meta property="og:url" content="https://www.pemaxx.com/"/>
    <meta property="og:title" content="Forex broker ECN, online Forex trading, stock trading ­— Pemaxx"/>
    <meta property="og:description" content="Trade with reliable broker and best conditions: low spreads, no swaps, no commissions. Claim and withdraw 50% deposit bonus!"/>
    <meta property="og:type" content="website"/>

    <meta property="og:site_name" content="Pemaxx">
    
    <meta property="twitter:url" content="https://www.pemaxx.com/">
    <meta property="twitter:card" content="summary">
    <meta property="twitter:title" content="Forex broker ECN, online Forex trading, stock trading ­— pemaxx">
    <meta property="twitter:description" content="Trade with reliable broker and best conditions: low spreads, no swaps, no commissions. Claim and withdraw 50% deposit bonus!">
    <meta itemprop="description" content="Trade with reliable broker and best conditions: low spreads, no swaps, no commissions. Claim and withdraw 50% deposit bonus!">
    <meta itemprop="url" content="https://www.pemaxx.com/">
    <meta name="twitter:site" content="@pemaxx">

    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="shortcut icon" href="assets/images/logo/favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/aos.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link rel="stylesheet" href="assets/css/color.css">
    <!-- Google reCAPTCHA CDN -->
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>

    <!-- Style -->
    <!--<link rel="stylesheet" href="assets/css/widget.css">-->

    <style>
        .form-control {
            padding: 10px;
        }
        .carousel-control-next, .carousel-control-prev {
            width: 10% !important;
        }
         @media (max-width: 1024px) {
    /* Hide the Sign IN and Sign UP buttons */
    .hide-on-ipad {
        display: none; /* Hide the buttons */
    }

    /* If you want to hide other elements in the header, add them here */
}


@media (max-width: 1024px) {
    /* Hide the Sign IN and Sign UP buttons */
    .hide-on-ipad {
        display: none; /* Hide the buttons */
    }

    /* If you want to hide other elements in the header, add them here */
}
    </style>

  </head>

  <body>

    <!-- Light Theme STart -->
      <div class="lightdark-switch d-none">
        <span class="dark-btn" id="btnSwitch"><img src="assets/images/icon/moon.svg" alt="light-dark-switchbtn"
            class="swtich-icon"></span>
      </div>
    <!-- Light Theme End -->


    <!-- Header Start -->
      <header class="header-section header-section--style2 header-mobile hide-on-ipad" style="background: #ffffffc4;">
        <div class="header-bottom">
            <div class="container-fluid" style="max-width : 1750px; height: 106px;">
                <div class="header-wrapper">
                    <div class="logo">
                        <a href="index.php">
                            <img class="dark img-fluid" src="assets/images/logo/logo2.png" alt="logo" >
                        </a>
                    </div>
                    <div class="menu-area">
                        <ul class="menu menu--style1">
                            <li><a href="index.php">Home </a></li>
                            <li><a href="about.php">About Us</a></li>
     <li class="nav-item dropdown">
    <a href="#">Trading</a>
    <ul class="submenu" style="width:750px;">
        <!-- First section: Your Finance -->
        <div class="submenu-section">
            <li class="section-title">Your Finance</li>
            <li><a href="depositswithdrawals.php">Deposits & Withdrawals</a></li>
            <li><a href="paymentoption.php">Payment Option</a></li>
            <li><a href="nigativebalance.php">Negative Balance</a></li>
            <li><a href="fundssecurity.php">Funds Security</a></li>
             <li><a href="live_market.php">Live Market</a></li>
        </div>

        <!-- Second section: Trading Condition -->
        <div class="submenu-section">
            <li class="section-title">Trading Condition</li>
            <li><a href="accounttype.php">Account Type</a></li>
            <li><a href="islamic_account.php">Islamic Account</a></li>
            <li><a href="Demo_account.php">Demo Account</a></li>
            <li><a href="Trading_advantages.php">Trading Advantages</a></li>
            <li><a href="spreadsandconditions.php">Spreads and Conditions</a></li>
        </div>

        <!-- Third section: Trading Platform -->
         <div class="submenu-section">
            <li class="section-title">Trading Platform</li>
             <li><a href=" https://download.mql5.com/cdn/mobile/mt5/android?server=PemaxxLiquidity-Server">Android</a></li>
         <li><a href="https://download.mql5.com/cdn/mobile/mt5/ios?server=PemaxxLiquidity-Server">IOS</a></li>
         <li><a href="https://download.mql5.com/cdn/web/pemaxx.liquidity.limited/mt5/pemaxxliquiditylimited5setup.exe">Windows</a></li>
         <li><a href="https://download.mql5.com/cdn/web/metaquotes.ltd/mt5/MetaTrader5.pkg.zip?utm_source=www.metatrader5.com&amp;utm_campaign=download.mt5.macos">maCos</a></li>
         <li><a href=" https://web.metatrader.app/terminal">Web Platform</a></li>
            <li><a href="learn more.php">Learn More</a></li>
        </div>

    </ul>
</li>
                             <li class="nav-item dropdown">
                                 <a href="#">Education</a>
                             <ul class="submenu" style="width:500px;">
                              <div class="submenu-section">
                        <li class="section-title">Traders tools</li>
                        <li><a href="pip_calculator.php">PIP Calculator</a></li>
                        <li><a href="risk_calculator.php">Risk Calculator</a></li>
                     <li><a href="margin_calculator.php">Margin Calculator</a></li>
                  <li><a href="profit_loss_calculator.php">P&L Calculator</a></li>
              </div>
              <div class="submenu-section" style="margin-bottom: 20px;">
            <li style="color: #808080; margin-bottom: 10px; font-weight: bold;" class="text-center">Education</li>
            <li><a href="trading_strategies.php">trading strategies</a></li>
         </div>  
 
               </ul>
             </li>


                          <!--  <li><a href="live_market.php">Live Market</a></li>-->
                            <!-- <li><a href="product.php">Products</a></li> -->
                            <li class="menu-item-has-children">
                              <a href="#">Social Trading</a>
                              <ul class="submenu">
                                <li><a href="https://socialsub.pemaxx.in:8081/widgets/ratings?widgetKey=social-ratings" target="_blank" rel="noopener">Social Rating</a></li>
                                <li><a href="https://social.pemaxx.in:8080/portal/" target="_blank" rel="noopener">Social Subscription </a></li>
                              </ul>
                            </li>
                            <li><a href="contact.php">Contact Us</a></li>
                            <li><a href="gallery.php">Gallery</a></li>
                            <li><a href="regulation.php">Certification</a></li>
                            <li class="d-lg-none d-sm-none d-block"><a href="https://crm.pemaxx.com/login" target="_blank" rel="noopener">Sign IN</a></li>
                            <li class="d-lg-none d-sm-none d-block"><a href="https://crm.pemaxx.com/register" target="_blank" rel="noopener">Open Account</a></li>
                        </ul>
    
                    </div>
    <!--                <span style="display: inline-block; width: 50px; height: 50px; border-radius: 50%; background-color: #00000033; text-align: center; line-height: 50px; color: white;">-->
    <!--    <i class="fa fa-download" style="font-size: 20px;"></i>-->
    <!--</span>-->
                    <div class="header-action">
                        <div class="menu-area">
                           <div class="header-action">
    <div class="menu-area">
        <div class="header-btn">
            <a href="https://crm.pemaxx.com/login" target="_blank" rel="noopener" class="trk-btn trk-btn--border trk-btn--primary hide-on-ipad"><span>Sign IN</span></a>
            <a href="https://crm.pemaxx.com/register" target="_blank" rel="noopener" class="trk-btn trk-btn--border trk-btn--primary hide-on-ipad"><span>Open Account</span></a>
        </div>
    </div>
</div>

<!-- <style>
    @media (max-width: 1024px) {
        .hide-on-ipad {
            display: none; /* Hide the buttons */
        }
    }
</style>
 -->
                                 
                              <!-- <div class="mobile-buttons d-lg-none d-sm"> 
        <a class="btn btn-outline-primary btn btn-sm" href="https://crm.pemaxx.com/register" style="font-size:9px;">Open Account</a>
        <a class="btn btn-outline-primary btn btn-sm" href="https://crm.pemaxx.com/login" style="font-size:9px;">Sign In</a>
      </div> -->

                            <!-- toggle icons -->
                             <div class="mobile-buttons d-lg-none d-sm"> 
                            <a class="btn btn-outline btn btn-sm text-white" href="https://crm.pemaxx.com/register" style="font-size:9px; background-color: #ff561c;">Open Account</a>
        <a class="btn btn-outline btn btn-sm text-white" href="https://crm.pemaxx.com/login" style="font-size:9px; background-color: #ff561c;">Sign In</a>
     </div>
                            <div class="header-bar d-lg-none header-bar--style1" style="margin-top:10px;">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                             
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </header>
    <!-- Header End -->
 
   
    <style>
        .form-control {
            padding: 10px;
        }


         /* .submenu {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background-color: #f8f9fa;
            z-index: 1;
            width: 100%;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }*/

        /* Show submenu on hover */
        li:hover > .submenu {
            /*display: flex;*/
        }

        /* Flexbox to align submenu items horizontally */
        .submenu {
            flex-direction: row; /* Align sections side by side */
            width: 800px;
        }

        /* Submenu section styling */
        .submenu-section {
            margin-right: 54px; /* Space between the sections */
        }

        /* Submenu item styling */
        .submenu li {
            list-style: none;
        }

        /* Links in submenu */
        .submenu a {
            padding: 5px 10px;
            display: block;
            white-space: nowrap; /* Prevent text from wrapping */
        }

        /* Optional hover effect */
        .submenu a:hover {
            background-color: #e2e6ea;
            border-radius: 5px;
        }

        /* Ensure navbar stays above the submenu */
        .navbar {
            position: relative;
            z-index: 2;
        }

          /* Media query for mobile view */
        @media (max-width: 768px) {
            .responsive-icon {
                width: 40px; /* Smaller width for mobile */
                height: 40px; /* Smaller height for mobile */
                line-height: 40px; /* Adjust line height for vertical centering */
            }

            .responsive-icon i {
                font-size: 16px; /* Smaller font size for mobile */
            }
        }


        /*new css*/


        /* Default web view (desktop) */
.submenu {
    display: flex;
    flex-direction: row;
    padding: 0;
    width: 750px; /* Original width for web view */
}

.submenu-section {
    margin-bottom: 20px;
}

.section-title {
    color: #808080;
    margin-bottom: 10px;
    font-weight: bold;
    text-align: center;
}

/* Mobile view */
@media (max-width: 768px) {
    .submenu {
        display: block; /* Stacking vertically for mobile */
        padding: 0;
        width: 100%; /* Full width for mobile */
    }

    
    .submenu-section li {
        font-size: 14px; /* Smaller font size for mobile */
    }

    .section-title {
        text-align: left; /* Align section titles to the left */
        font-size: 16px; /* Slightly smaller section titles */
        margin-bottom: 5px;
    }
}
@media only screen and (max-width: 1024px) {
    .header-btn {
        display: none;
    }
}


 @media (max-width: 1024px) {
    /* Hide the Sign IN and Sign UP buttons */
    .hide-on-ipad {
        display: none; /* Hide the buttons */
    }

    /* If you want to hide other elements in the header, add them here */
}

       
    </style>

  </head>

  <body>

    <!-- Light Theme STart -->
      <div class="lightdark-switch d-none">
        <span class="dark-btn" id="btnSwitch"><img src="assets/images/icon/moon.svg" alt="light-dark-switchbtn"
            class="swtich-icon"></span>
      </div>
    <!-- Light Theme End -->


    <!-- Header Start -->
      <header class="header-section header-section--style2 header-mobile" style="background: #ffffffc4;">
        <div class="header-bottom">
            <div class="container-fluid" style="max-width : 1750px; height:106px;">
                <div class="header-wrapper">
                    <div class="logo">
                        <a href="index.php">
                            <img class="dark img-fluid" src="assets/images/logo/logo2.png" alt="logo" >
                        </a>
                    </div>
                    <div class="menu-area">
                        <ul class="menu menu--style1">
                            <li><a href="index.php">Home </a></li>
                            <li><a href="about.php">About Us</a></li>
                           <!-- <li><a href="#">Treding</a>
                            <ul class="submenu">
                             <li><a href="depositswithdrawals.php">Deposits and Withdrawals</a></li>
                                 <li><a href="paymentoption.php">Payment Option</a></li>
                                 <li><a href="nigativebalance.php">Nigative Balance</a></li>
                                 <li><a href="fundssecurity.php">Funds Security</a></li>
                                 <li><a href="accounttype.php">Account Type</a></li>
                                 <li><a href="spreadsandconditions.php">Spreads and Conditions</a></li>
                                 <li><a href="whychooseus.php">Why Choose Us</a></li>
                               </ul>
                               </li> -->
     <li class="nav-item dropdown">
    <a href="#">Trading</a>
    <ul class="submenu" style="width:750px;">
        <!-- First section: Your Finance -->
        <div class="submenu-section">
            <li class="section-title">Your Finance</li>
            <li><a href="depositswithdrawals.php">Deposits & Withdrawals</a></li>
            <li><a href="paymentoption.php">Payment Option</a></li>
            <li><a href="nigativebalance.php">Negative Balance</a></li>
            <li><a href="fundssecurity.php">Funds Security</a></li>
             <li><a href="live_market.php">Live Market</a></li>
        </div>

        <!-- Second section: Trading Condition -->
        <div class="submenu-section">
            <li class="section-title">Trading Condition</li>
            <li><a href="accounttype.php">Account Type</a></li>
            <li><a href="islamic_account.php">Islamic Account</a></li>
            <li><a href="Demo_account.php">Demo Account</a></li>
            <li><a href="Trading_advantages.php">Trading Advantages</a></li>
            <li><a href="spreadsandconditions.php">Spreads and Conditions</a></li>
        </div>

        <!-- Third section: Trading Platform -->
        <div class="submenu-section">
            <li class="section-title">Trading Platform</li>
             <li><a href=" https://download.mql5.com/cdn/mobile/mt5/android?server=PemaxxLiquidity-Server">Android</a></li>
         <li><a href="https://download.mql5.com/cdn/mobile/mt5/ios?server=PemaxxLiquidity-Server">IOS</a></li>
         <li><a href="https://download.mql5.com/cdn/web/pemaxx.liquidity.limited/mt5/pemaxxliquiditylimited5setup.exe">Windows</a></li>
         <li><a href="https://download.mql5.com/cdn/web/metaquotes.ltd/mt5/MetaTrader5.pkg.zip?utm_source=www.metatrader5.com&amp;utm_campaign=download.mt5.macos">maCos</a></li>
         <li><a href=" https://web.metatrader.app/terminal">Web Platform</a></li>
            <li><a href="learn more.php">Learn More</a></li>
        </div>
    </ul>
</li>

                         <li class="nav-item dropdown">
                                 <a href="#">Education</a>
                             <ul class="submenu" style="width:500px;">
                              <div class="submenu-section">
                        <li class="section-title">Traders tools</li>
                        <li><a href="pip_calculator.php">PIP Calculator</a></li>
                        <li><a href="risk_calculator.php">Risk Calculator</a></li>
                     <li><a href="margin_calculator.php">Margin Calculator</a></li>
                  <li><a href="profit_loss_calculator.php">P&L Calculator</a></li>
              </div>
               <div class="submenu-section" style="margin-bottom: 20px;">
            <li style="color: #808080; margin-bottom: 10px; font-weight: bold;" class="text-center">Education</li>
            <li><a href="trading_strategies.php">trading strategies</a></li>
         </div>   
 
               </ul>
             </li>


                              <!-- <li><a href="live_market.php">Live Market</a></li>-->
                               <!-- <li><a href="product.php">Products</a></li> -->
                            <li class="menu-item-has-children">
                              <a href="#">Social Trading</a>
                              <ul class="submenu">
                                <li><a href="https://socialsub.pemaxx.in:8081/widgets/ratings?widgetKey=social-ratings" target="_blank" rel="noopener" >Social Rating</a></li>
                                <li><a href="https://social.pemaxx.in:8080/portal/" target="_blank" rel="noopener" >Social Subscription </a></li>
                              </ul>
                            </li>
                            <li><a href="contact.php">Contact Us</a></li>
                            <li><a href="gallery.php">Gallery</a></li>
                            <li><a href="regulation.php">Certification</a></li>
                            <li class="d-lg-none d-sm-none d-block"><a href="https://crm.pemaxx.com/login" target="_blank" rel="noopener">Sign IN</a></li>
                            <li class="d-lg-none d-sm-none d-block"><a href="https://crm.pemaxx.com/register" target="_blank" rel="noopener">Open Account</a></li>
                        </ul>
                    </div>
    <!--                <span style="display: inline-block; width: 50px; height: 50px; border-radius: 50%; background-color: #00000033; text-align: center; line-height: 50px; color: white;">-->
    <!--    <i class="fa fa-download" style="font-size: 20px;"></i>-->
    <!--</span>-->
                    <div class="header-action">
                        <div class="menu-area">
                            <div class="header-action">
    <div class="menu-area">
        <div class="header-btn">
            <a href="https://crm.pemaxx.com/login" target="_blank" rel="noopener" class="trk-btn trk-btn--border trk-btn--primary hide-on-ipad"><span>Sign IN</span></a>
            <a href="https://crm.pemaxx.com/register" target="_blank" rel="noopener" class="trk-btn trk-btn--border trk-btn--primary hide-on-ipad"><span>Open Account</span></a>
        </div>
    </div>
</div>

                           <!--  <div class="mobile-buttons d-lg-none d-sm"> 
        <a class="btn btn-outline-primary btn btn-sm" href="https://crm.pemaxx.com/register" style="font-size:9px;">Open Account</a>
        <a class="btn btn-outline-primary btn btn-sm" href="https://crm.pemaxx.com/login" style="font-size:9px;">Sign In</a>
      </div> -->
    
                            <!-- toggle icons -->
                            <div class="mobile-buttons d-lg-none d-sm"> 
                            <a class="btn btn-outline btn btn-sm text-white" href="https://crm.pemaxx.com/register" style="font-size:9px; background-color: #ff561c;">Open Account</a>
        <a class="btn btn-outline btn btn-sm text-white" href="https://crm.pemaxx.com/login" style="font-size:9px; background-color: #ff561c;">Sign In</a>
     </div>
                            <div class="header-bar d-lg-none header-bar--style1" style="margin-top:10px">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </header> 
